vncserver -geometry 1600x900
