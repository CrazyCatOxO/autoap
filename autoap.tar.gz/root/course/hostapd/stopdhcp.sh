/etc/init.d/isc-dhcp-server stop
dhclient -r wlan1
