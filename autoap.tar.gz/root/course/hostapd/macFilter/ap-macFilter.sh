#!/bin/bash

startNAT
hostapd /root/course/hostapd/macFilter/hostapd-macFilter.conf
