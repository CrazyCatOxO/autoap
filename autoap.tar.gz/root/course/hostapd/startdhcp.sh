#!/bin/bash

ifconfig wlan0 up
ifconfig wlan1 up

ifconfig wlan1 192.168.5.1
/etc/init.d/isc-dhcp-server start 
