#!/bin/bash

startNAT
hostapd /root/course/hostapd/hidden/hostapd-hidden.conf
