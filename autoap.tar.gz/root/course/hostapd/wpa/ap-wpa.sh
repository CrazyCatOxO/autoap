#!/bin/bash

startNAT
hostapd /root/course/hostapd/wpa/hostapd-wpa.conf
