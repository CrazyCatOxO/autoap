#!/bin/bash

startNAT
hostapd /root/course/hostapd/open/hostapd-open.conf
