#!/bin/bash

stopdhcp
sysctl net.ipv4.ip_forward=0
iptables -t nat -F POSTROUTING
