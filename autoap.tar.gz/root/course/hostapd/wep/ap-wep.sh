#!/bin/bash

startNAT
hostapd /root/course/hostapd/wep/hostapd-wep.conf
